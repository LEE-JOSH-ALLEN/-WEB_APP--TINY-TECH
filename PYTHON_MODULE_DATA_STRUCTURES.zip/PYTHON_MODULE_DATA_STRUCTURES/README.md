Naka hanap na me ng mga videos for these topics
pero since hindi kasi sila specifically for each of those topics
kaya kina-cut ko yung mga videos para mas maganda