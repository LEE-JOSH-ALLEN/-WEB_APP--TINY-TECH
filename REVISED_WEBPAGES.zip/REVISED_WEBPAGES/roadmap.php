<?php
session_start();
require_once 'auth.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id']) || !validateUserSession($_SESSION['user_id'])) {
    header("Location: login-page.php");
    exit;
}

// Get user data
$user = getUserById($_SESSION['user_id']);

// Check for toast message
$toastMessage = '';
$toastType = 'success';
if (isset($_SESSION['toast_message'])) {
    $toastMessage = $_SESSION['toast_message'];
    $toastType = $_SESSION['toast_type'] ?? 'success';
    unset($_SESSION['toast_message']);
    unset($_SESSION['toast_type']);
}

//Setting completedModules variable
$course_1 = 1;
$course_2 = 2;
$course_3 = 3;
$course_4 = 4;
$course_5 = 5;
$course_6 = 6;

$completedModules_1 = isset($_SESSION['course_progress'][$course_1]) ? count($_SESSION['course_progress'][$course_1]) : 0;
$completedModules_2 = isset($_SESSION['course_progress'][$course_2]) ? count($_SESSION['course_progress'][$course_2]) : 0;
$completedModules_3 = isset($_SESSION['course_progress'][$course_3]) ? count($_SESSION['course_progress'][$course_3]) : 0;
$completedModules_4 = isset($_SESSION['course_progress'][$course_4]) ? count($_SESSION['course_progress'][$course_4]) : 0;
$completedModules_5 = isset($_SESSION['course_progress'][$course_5]) ? count($_SESSION['course_progress'][$course_5]) : 0;
$completedModules_6 = isset($_SESSION['course_progress'][$course_6]) ? count($_SESSION['course_progress'][$course_6]) : 0;

$lesson_val = $completedModules_1+$completedModules_2+$completedModules_3+$completedModules_4+$completedModules_5+$completedModules_6;


// Handle start button clicks
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_course'])) {
    $course_id = intval($_POST['course_id']);
    
    // Update course status to active
    $stmt = $pdo->prepare("UPDATE courses SET is_active = 1 WHERE course_id = ?");
    $stmt->execute([$course_id]);
    
    // Create a user progress record
    $stmt = $pdo->prepare("INSERT INTO user_progress (user_id, course_id, start_date) VALUES (?, ?, NOW())");
    $stmt->execute([$_SESSION['user_id'], $course_id]);
    
    $_SESSION['toast_message'] = "Course started successfully!";
    $_SESSION['toast_type'] = 'success';
    
    // Redirect to prevent form resubmission
    header("Location: roadmap.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_module'])) {
    $module_id = intval($_POST['module_id']);
    
    // Update module status to active
    $stmt = $pdo->prepare("UPDATE modules SET is_active = 1 WHERE module_id = ?");
    $stmt->execute([$module_id]);
    
    // Also update the parent course to active
    $stmt = $pdo->prepare("
        UPDATE courses c 
        JOIN modules m ON c.course_id = m.course_id 
        SET c.is_active = 1 
        WHERE m.module_id = ?
    ");
    $stmt->execute([$module_id]);
    
    $_SESSION['toast_message'] = "Module started successfully!";
    $_SESSION['toast_type'] = 'success';
    
    // Redirect to prevent form resubmission
    header("Location: roadmap.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Tiny Tech - Roadmap</title>

  <!-- Bootstrap + Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Press+Start+2P&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Your Styles -->
  <style>
    :root {
    --primary-color: #ffd966;
    --secondary-color: #4D44DB;
    --condition-color: #FF7E33;
    --loop-color: #33C2FF;
    --variable-color: #8A2BE2;
    --function-color: #4CAF50;
    --light-bg: #F8F9FA;
    --dark-text: #2D3748;
    --light-text: #718096;
    }

    /* === Reset === */
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    }

    /* === Body Background === */
    body {
    font-family: 'Poppins', sans-serif;
    overflow-x: hidden;
    color: var(--dark-text);

    /* Animated gradient background */
    background: linear-gradient(270deg, #87CEEB, #a8edea, #fed6e3, #e2ebf0);
    background-size: 800% 800%;
    animation: gradientMove 15s ease infinite;
    }

    /* Gradient Animation */
    @keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
    }

    /* === Navbar === */
    .top-nav {
    background-color: #0d0d1a;
    padding: 8px 30px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.7);
    z-index: 1000;
    margin-bottom: 10px;
    }

    nav {
    position: relative;
    z-index: 150;
    }

    .logo-img {
    height: 60px;
    }

    .nav-link {
    font-family: 'Press Start 2P', cursive;
    font-size: 14px;
    color: #fff !important;
    }

    .nav-link:hover {
    color: #ffd966 !important;
    }

    .profile-link {
    color: #fff !important;
    }

    .search-input,
    .search-input-mobile {
    background-color: #1f1f2e;
    border: none;
    color: #fff;
    font-family: 'Poppins', sans-serif;
    padding: 5px 10px;
    }

    .search-input::placeholder,
    .search-input-mobile::placeholder {
    color: #aaa;
    }

    .info-panel {
    background-color: #000c19;
    padding: 20px;
    border-radius: 15px;
    box-shadow: 0 0 15px rgba(0,0,0,0.3);
    }

    .avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #ffc107;
    }

    .sidebar-btn {
    background-color: #000c19;
    border: 2px solid #ffc107;
    border-radius: 12px;
    color: #ffd700;
    font-weight: bold;
    padding: 10px 16px;
    transition: 0.3s;
    }

    .sidebar-btn:hover {
    background-color: #5d296f;
    }

    .tip-box {
    background-color: #3a2450;
    border-left: 5px solid #ffc107;
    border-radius: 8px;
    }

    .chapter-card {
    max-height: 125px;
    background-color: #2e1c40;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    transition: transform 0.3s ease;
    }

    .chapter-card:hover {
    transform: translateY(-3px);
    }

    .chapter-info {
    flex: 1;
    }

    .chapter-img-container {
    position: relative;
    max-width: 320px;
    width: 100%;
    }

    .chapter-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    border-left: 3px solid #3a2450;
    }

    .btn-circle {
    position: absolute;
    bottom: 20px;
    right: 15px;
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background-color: #f6db65;
    color: bla;
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    box-shadow: 0 2px 6px rgba(0,0,0,0.5);
    }

    .btn-circle:hover {
    background-color: #3700b3;
    }

    .chapter-title {
    font-family: 'Fredoka One', sans-serif;
    font-size: 1.25rem;
    font-weight: bold;
    color: #ffb74d;
    margin-bottom: 4px;
    }

    .chapter-subtitle {
    font-family: 'Poppins', sans-serif;
    font-size: 0.95rem;
    color: #f1e7b3;
    }

    .chapter-arrow {
    font-size: 1.5rem;
    color: #fbc02d;
    }

    .chapter-arrow {
    font-size: 1.5rem;
    color: #fbc02d;
    transition: transform 0.3s ease;
    }

    .chapter-arrow.rotate {
    transform: rotate(-90deg);
    }

    .footer-dark {
    background-color: #0d0d1a;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    font-family: 'Poppins', sans-serif;
    }

    .footer-dark h4,
    .footer-dark h6 {
    font-size: 1.3rem;
    font-weight: 700;
    }

    .footer-link {
    color: #ccc;
    text-decoration: none;
    display: block;
    margin-bottom: 0.5rem;
    transition: color 0.2s;
    }

    .footer-link:hover {
    color: #ffd966 /* Bootstrap info color */
    }

    .social-icon {
    width: 40px;
    height: 40px;
    background: rgba(255, 255, 255, 0.05);
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: #fff;
    transition: all 0.3s ease;
    font-size: 1.1rem;
    }

    .social-icon:hover {
    background: #ffd966;
    color: #fff;
    }

    .social-icon img {
    width: 40px;       /* adjust size */
    height: 40px;      /* adjust size */
    border-radius: 50%; /* makes it circular */
    transition: transform 0.3s; /* smooth hover effect */
    }

    .social-icon img:hover {
    transform: scale(1.1); /* slight zoom on hover */
    }


    .footer-bottom {
    background: #181827;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
    }

    .card-dark {
    background: #10121A;
    border: 1px solid #2A2D3A;
    border-radius: 12px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.4);
    color: #fff;
    }

    .learning-path {
    border-left: 2px solid #2A2D3A;
    position: relative;
    }

    .module {
    margin-bottom: 30px;
    }

    .module-circle {
    width: 40px;
    height: 40px;
    background: #161A23;
    border: 2px solid #4D4D6A;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    margin-right: 15px;
    }

    .module-title {
    font-size: 1.3rem;
    font-weight: 700;
    color: #fff;
    }

    .toggle {
    font-size: 14px;
    cursor: pointer;
    color: #aaa;
    }

    .exercise-list {
    list-style: none;
    padding-left: 60px;
    }

    .exercise-list li {
    display: flex;
    justify-content: space-between;
    padding: 10px;
    background: #161A23;
    border-radius: 8px;
    margin-bottom: 8px;
    }

    .start-btn {
    background: #ffb74d;
    border: none;
    padding: 5px 15px;
    font-family: 'Press Start 2P', cursive;
    color: white;
    border-radius: 6px;
    }

    .profile-name {
    font-family: 'Poppins', sans-serif;
    font-size: 1rem;
    font-weight: 700;
    color: #ffb74d;
    }


    .locked-btn {
    background: #2A2D3A;
    color: #666;
    padding: 5px 15px;
    border: none;
    font-family: 'Press Start 2P', cursive;
    }

    .profile-pixel {
    width: 50px;
    image-rendering: pixelated;
    }

    .profile-btn {
    border: 2px solid #4D4D6A;
    background: transparent;
    color: #fff;
    padding: 6px 12px;
    font-family: 'Press Start 2P', cursive;
    }

    .progress-item {
    display: flex;
    align-items: center;
    margin-bottom: 8px;
    font-size: 14px;
    }

    .progress-item .icon {
    width: 20px;
    margin-right: 10px;
    }

    .progress-bar-pixel {
    background: #2A2D3A;
    height: 10px;
    border-radius: 6px;
    margin-bottom: 15px;
    overflow: hidden;
    }

    .progress-bar-pixel div {
    background: #2D9CDB;
    height: 100%;
    }

    /* Hide module bodies by default */
    .collapse-content {
    display: none;
    margin-top: 15px;
    }

    /* Rotate arrow when open */
    .module.open .toggle {
    transform: rotate(180deg);
    transition: transform 0.3s ease;
    }

    .toggle {
    transition: transform 0.3s ease;
    font-size: 14px;
    cursor: pointer;
    color: #aaa;
    }

    .learning-path, .card-dark {
    border-radius: 15px;
    margin-bottom: 25px;
    }

    @media (min-width: 992px) {
    .col-lg-8 {
        padding-right: 20px;
    }
    .col-lg-4 {
        padding-left: 20px;
    }
    }
  </style>
</head>
<body>
  <!-- ===== NAVBAR ===== -->
  <nav class="navbar navbar-expand-lg top-nav sticky-top navbar-dark">
    <div class="container-fluid d-flex justify-content-between align-items-center">
      <!-- Logo -->
      <a class="navbar-brand" href="dashboard.php">
        <img src="logo.png" alt="Tiny Tech Logo" class="logo-img">
      </a>

      <!-- Mobile Search -->
      <div class="d-lg-none d-flex align-items-center gap-2">
        <input class="form-control form-control-sm search-input-mobile" type="search" placeholder="Search" aria-label="Search">
      </div>

      <!-- Hamburger -->
      <button class="navbar-toggler ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Collapsible -->
      <div class="collapse navbar-collapse justify-content-between" id="navbarContent">
        <!-- Links -->
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0 text-center">
          <li class="nav-item"><a class="fw-bold nav-link" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="fw-bold nav-link" href="roadmap.php">Explore</a></li>
          <li class="nav-item"><a class="fw-bold nav-link" href="#">Ideas</a></li>
          <li class="nav-item"><a class="fw-bold nav-link" href="about.php">About</a></li>
        </ul>

        <!-- Desktop Search + Profile -->
        <form class="d-none d-lg-flex align-items-center gap-2" role="search">
          <input class="form-control form-control-sm search-input" type="search" placeholder="Search..." aria-label="Search">
          <div class="dropdown">
            <a class="d-flex align-items-center gap-2 text-decoration-none dropdown-toggle profile-link" href="#" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?php echo !empty($user['profile_image_url']) ? htmlspecialchars($user['profile_image_url']) : 'assets/user-profile.jpg'; ?>" alt="Profile" class="rounded-circle" width="32" height="32">
              <span class="fw-bold"><?php echo htmlspecialchars($user['username']); ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
              <li><a class="dropdown-item" href="user-profile.php">Profile</a></li>
              <li><a class="dropdown-item" href="#">Progress</a></li>
              <li><a class="dropdown-item" href="#">Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="logout.php">Sign Out</a></li>
            </ul>
          </div>
        </form>
      </div>
    </div>
  </nav>

  <div class="container mt-5 px-4">
    <div class="row">
      <!-- Left: Learning Path -->
      <div class="col-lg-8">
        <div class="learning-path card-dark p-4">
          <?php
          // Define course mapping
          $courseMapping = [
            1 => [
              'title' => 'Python Basics',
              'json' => 'PYTHON-MODULE-1_BASICS.json',
              'modules' => []
            ],
            2 => [
              'title' => 'Control Flow',
              'json' => 'PYTHON-MODULE-2_CONTROL_FLOW.json',
              'modules' => []
            ],
            3 => [
              'title' => 'Data Structures',
              'json' => 'PYTHON-MODULE-3_DATA_STRUCTURES.json',
              'modules' => []
            ],
            4 => [
              'title' => 'Functions',
              'json' => 'PYTHON-MODULE-4_FUNCTIONS.json',
              'modules' => []
            ],
            5 => [
              'title' => 'Error Handling',
              'json' => 'PYTHON-MODULE-5_ERROR_HANDLING.json',
              'modules' => []
            ],
            6 => [
              'title' => 'Module Importation',
              'json' => 'PYTHON-MODULE-6_MODULE_IMPORTATION.json',
              'modules' => []
            ]
          ];
          
          // Load module data from JSON files
          foreach ($courseMapping as $courseId => &$course) {
            if (file_exists($course['json'])) {
              $jsonContent = file_get_contents($course['json']);
              $data = json_decode($jsonContent, true);
              
              if ($data && isset($data['modules'][0]['topics'])) {
                $course['modules'] = $data['modules'][0]['topics'];
              }
            }
          }
          
          // Display courses and modules
          $moduleCount = 1;
          foreach ($courseMapping as $courseId => $course) {
            ?>
            <div class="module">
              <div class="module-header d-flex justify-content-between align-items-center toggle-header">
                <div class="d-flex align-items-center">
                  <span class="module-circle"><?php echo $moduleCount++; ?></span>
                  <h5 class="module-title"><?php echo htmlspecialchars($course['title']); ?></h5>
                </div>
                <span class="toggle">▼</span>
              </div>
              <div class="module-body collapse-content">
                <ul class="exercise-list">
                  <?php foreach ($course['modules'] as $moduleIndex => $module): ?>
                  <li>
                    <span>Lesson <?php echo $moduleIndex + 1; ?></span>
                    <span><?php echo htmlspecialchars($module['title']); ?></span>
                    <a href="modules.php?course=<?php echo $courseId; ?>&topic=<?php echo $moduleIndex; ?>" class="start-btn">Start</a>
                  </li>
                  <?php endforeach; ?>
                </ul>
              </div>
            </div>
            <?php
          }
          ?>
        </div>
      </div>

      <!-- Right: Profile + Progress -->
      <div class="col-lg-4">
        <!-- Profile Card -->
        <div class="card-dark p-4 mb-4 text-center">
          <img src="<?php echo !empty($user['profile_image_url']) ? htmlspecialchars($user['profile_image_url']) : 'https://cdn-icons-png.flaticon.com/512/147/147144.png'; ?>" class="profile-pixel" alt="Profile" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover;">
          <h5 class="profile-name mt-2"><?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></h5>
          <small class="text-white fw-medium">Level <?php echo isset($user['current_level']) ? $user['current_level'] : 1; ?></small>
        </div>

        <!-- Course Progress -->
        <div class="card-dark p-4">
          <h6 class="text-white mb-3">Course Progress</h6>
          <div class="progress-item">
            <img src="https://cdn-icons-png.flaticon.com/512/1828/1828930.png" class="icon"> 
            <span>Lesson</span>
            <small class="ms-auto"><?php echo $lesson_val; ?>/49</small>
          </div>
          <div class="progress-bar-pixel"><div style="width:<?php echo $lesson_val / 49 * 100; ?>%"></div></div>

          <div class="progress-item">
            <img src="https://cdn-icons-png.flaticon.com/512/414/414927.png" class="icon"> 
            <span>Exercise Completed</span>
            <small class="ms-auto">0/2</small>
          </div>
          <div class="progress-bar-pixel"><div style="width:0%"></div></div>

          <div class="progress-item">
            <img src="https://cdn-icons-png.flaticon.com/512/616/616408.png" class="icon"> 
            <span>XP Earned</span>
            <small class="ms-auto"><?php echo isset($user['xp_points']) ? $user['xp_points'] : 0; ?>/685</small>
          </div>
          <div class="progress-bar-pixel"><div style="width:<?php echo isset($user['xp_points']) ? ($user['xp_points'] / 685 * 100) : 0; ?>%"></div></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ===== Footer ===== -->
  <footer class="footer-dark mt-5">
    <div class="container py-5">
      <div class="row gy-4">
        <!-- Brand -->
        <div class="col-lg-4">
          <h4 class="text-white fw-bold">Tiny Tech</h4>
          <p class="text-white-50">
            Empowering learners with modern tech skills and hands-on coding experience.
          </p>
        </div>

        <!-- Quick Links -->
        <div class="col-lg-4">
          <h6 class="text-white fw-bold mb-3">Quick Links</h6>
          <ul class="list-unstyled">
            <li><a href="#" class="footer-link">About Us</a></li>
            <li><a href="#" class="footer-link">Contact</a></li>
            <li><a href="#" class="footer-link">Privacy Policy</a></li>
            <li><a href="#" class="footer-link">Terms of Service</a></li>
          </ul>
        </div>

        <!-- Social Media -->
        <div class="col-lg-4">
          <h6 class="text-white fw-bold mb-3">Connect With Us</h6>
            <div class="d-flex gap-3">
              <a href="#" class="social-icon">
                <img src="assets/facebook.png" alt="Facebook">
              </a>
              <a href="#" class="social-icon">
                <img src="assets/x.png" alt="Twitter">
              </a>
              <a href="#" class="social-icon">
                <img src="assets/linkedin.png" alt="LinkedIn">
              </a>
              <a href="#" class="social-icon">
                <img src="assets/github.png" alt="GitHub">
              </a>
            </div>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  
  <!-- Toast Notification Script -->
  <script src="toast.js"></script>
  
  <?php if ($toastMessage): ?>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      showToast('<?php echo $toastMessage; ?>', '<?php echo $toastType; ?>');
    });
  </script>
  <?php endif; ?>

  <!-- Your Toggle Arrow Script -->
  <script>
    document.querySelectorAll('.chapter-arrow').forEach((arrow) => {
      arrow.style.cursor = 'pointer';

      arrow.addEventListener('click', () => {
        const chapterCard = arrow.closest('.chapter-info');
        const details = chapterCard.querySelector('.chapter-details');
        
        if (details.style.display === 'none' || details.style.display === '') {
          details.style.display = 'block';
          arrow.textContent = '►'; 
        } else {
          details.style.display = 'none';
          arrow.textContent = '▼';
        }
      });
    });
  </script>

  <script>
    document.querySelectorAll(".toggle-header").forEach(header => {
      header.addEventListener("click", () => {
        const module = header.parentElement;
        module.classList.toggle("open");
        const body = module.querySelector(".collapse-content");
        body.style.display = body.style.display === "block" ? "none" : "block";
      });
    });
  </script>

</body>
</html>