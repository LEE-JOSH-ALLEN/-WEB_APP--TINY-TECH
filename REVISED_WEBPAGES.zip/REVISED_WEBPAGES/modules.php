<?php
session_start();
require_once 'auth.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id']) || !validateUserSession($_SESSION['user_id'])) {
    header("Location: login-page.php");
    exit;
}

// Get user data
$user = getUserById($_SESSION['user_id']);

// Check for toast message
$toastMessage = '';
$toastType = 'success';
if (isset($_SESSION['toast_message'])) {
    $toastMessage = $_SESSION['toast_message'];
    $toastType = $_SESSION['toast_type'] ?? 'success';
    unset($_SESSION['toast_message']);
    unset($_SESSION['toast_type']);
}

// Get course and topic parameters from URL
$courseId = isset($_GET['course']) ? intval($_GET['course']) : 1;
$topicId = isset($_GET['topic']) ? intval($_GET['topic']) : 0;

// Define course mapping
$courseMapping = [
    1 => [
        'title' => 'Python Basics',
        'json' => 'PYTHON-MODULE-1_BASICS.json',
        'next_course' => 2
    ],
    2 => [
        'title' => 'Control Flow', 
        'json' => 'PYTHON-MODULE-2_CONTROL_FLOW.json',
        'next_course' => 3
    ],
    3 => [
        'title' => 'Data Structures',
        'json' => 'PYTHON-MODULE-3_DATA_STRUCTURES.json',
        'next_course' => 4
    ],
    4 => [
        'title' => 'Functions',
        'json' => 'PYTHON-MODULE-4_FUNCTIONS.json',
        'next_course' => 5
    ],
    5 => [
        'title' => 'Error Handling', 
        'json' => 'PYTHON-MODULE-5_ERROR_HANDLING.json',
        'next_course' => 6
    ],
    6 => [
        'title' => 'Module Importation',
        'json' => 'PYTHON-MODULE-6_MODULE_IMPORTATION.json',
        'next_course' => null
    ],
];

// Load the appropriate JSON file based on course
$jsonFile = isset($courseMapping[$courseId]) ? $courseMapping[$courseId]['json'] : $courseMapping[1]['json'];
$courseData = null;

if (file_exists($jsonFile)) {
    $jsonContent = file_get_contents($jsonFile);
    $courseData = json_decode($jsonContent, true);
}

// Validate topic ID
if ($courseData && isset($courseData['modules'][0]['topics'])) {
    $maxTopicId = count($courseData['modules'][0]['topics']) - 1;
    if ($topicId > $maxTopicId) {
        $topicId = $maxTopicId;
    } elseif ($topicId < 0) {
        $topicId = 0;
    }
}

// Save last visited module
$_SESSION['last_visited'] = [
    'course' => $courseId,
    'topic' => $topicId,
    'course_title' => isset($courseMapping[$courseId]) ? $courseMapping[$courseId]['title'] : 'Unknown Course',
    'timestamp' => time()
];

// Initialize session progress tracking if not exists
if (!isset($_SESSION['course_progress'])) {
    $_SESSION['course_progress'] = [];
}
if (!isset($_SESSION['course_progress'][$courseId])) {
    $_SESSION['course_progress'][$courseId] = [];
}

// Get total number of modules in this course
$totalModules = 0;
if ($courseData && isset($courseData['modules'][0]['topics'])) {
    $totalModules = count($courseData['modules'][0]['topics']);
}

// Handle module completion when user visits a topic
if ($courseData && isset($courseData['modules'][0]['topics'][$topicId])) {
    // Mark this module as completed
    $_SESSION['course_progress'][$courseId][$topicId] = true;
    
    // Show completion message if this is the first time visiting this module
    if (!isset($_SESSION['last_completed_module']) || 
        $_SESSION['last_completed_module'] != $courseId . '_' . $topicId) {
        
        $_SESSION['last_completed_module'] = $courseId . '_' . $topicId;
        
        // Calculate remaining modules
        $completedModules = count($_SESSION['course_progress'][$courseId]);
        $_SESSION['completed_modules'] = $completedModules;
        $remainingModules = $totalModules - $completedModules;
        
        if ($remainingModules > 0) {
            $_SESSION['toast_message'] = "Module completed! $remainingModules modules remaining.";
            $_SESSION['toast_type'] = 'success';
        } else {
            $_SESSION['toast_message'] = "Congratulations! You've completed all modules in this course!";
            $_SESSION['toast_type'] = 'success';
        }
        
        // Redirect to show the toast message
        header("Location: modules.php?course={$courseId}&topic={$topicId}");
        exit;
    }
}

// Check if user has completed all modules in this course
$allModulesCompleted = false;
$completedModules = 0;

if ($totalModules > 0) {
    $completedModules = count($_SESSION['course_progress'][$courseId]);
    $allModulesCompleted = ($completedModules >= $totalModules);
}

// Get current topic data
$currentTopic = null;
if ($courseData && isset($courseData['modules'][0]['topics'][$topicId])) {
    $currentTopic = $courseData['modules'][0]['topics'][$topicId];
}

// Handle next level button click
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['next_level'])) {
    if ($allModulesCompleted) {
        // Get the next course ID
        $nextCourseId = isset($courseMapping[$courseId]['next_course']) ? $courseMapping[$courseId]['next_course'] : null;
        
        if ($nextCourseId) {
            // Redirect to the next course
            header("Location: modules.php?course={$nextCourseId}&topic=0");
            exit;
        } else {
            // No next course, redirect to dashboard
            $_SESSION['toast_message'] = "Congratulations! You've completed all available courses.";
            $_SESSION['toast_type'] = 'success';
            header("Location: dashboard.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Tiny Tech - <?php echo isset($courseMapping[$courseId]) ? $courseMapping[$courseId]['title'] : 'Python Modules'; ?></title>

  <!-- Bootstrap + Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Press+Start+2P&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    :root {
      --primary-color: #6C63FF;
      --secondary-color: #4D44DB;
      --condition-color: #FF7E33;
      --loop-color: #33C2FF;
      --variable-color: #8A2BE2;
      --function-color: #4CAF50;
      --light-bg: #F8F9FA;
      --dark-text: #2D3748;
      --light-text: #718096;
    }

    body {
      font-family: 'Poppins', sans-serif !important;
      background-color: #ffffff !important;
    }

    .top-nav {
      background-color: #0d0d1a;
      padding: 8px 30px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.5);
      z-index: 1000;
      height: 70px; 
      display: flex;
      align-items: center; 
    }

    img.rounded-circle {
      object-fit: cover;
    }

    .logo-img {
      height: 80px; 
      width: auto;
      max-height: 80px; 
    }

    .nav-link {
      font-weight: 500;
      font-family: 'Poppins', sans-serif;
      transition: 0.3s;
      color: #fff !important;
    }

    .nav-link:hover {
      text-decoration: underline;
      color: #ffd966 !important;
    }

    @media (max-width: 991.98px) {
      .navbar-collapse {
        background-color: #0d0d1a;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        margin-top: 10px;
      }

      .navbar-nav .nav-item {
        margin-bottom: 10px;
      }

      .navbar-collapse .nav-link {
        display: block;
        text-align: center;
        padding: 10px 0;
        border-radius: 8px;
        background-color: #1a1a2e;
        color: #fff !important;
      }

      .navbar-collapse .nav-link:hover {
        background-color: #2a2a3e;
        color: #ffd966 !important;
      }
    }

    @media (max-width: 767.98px) {
      .logo-img {
        height: 50px;
      }
    }

    .dropdown-menu {
      font-family: 'Poppins', sans-serif;
      background-color: #0d0d1a;
      border: none;
      box-shadow: 0 4px 8px rgba(0,0,0,0.15);
      color: #fff;
    }

    .dropdown-item {
      color: #fff !important;
    }

    .dropdown-item:hover {
      background-color: #1a1a2e;
      color: #ffd966 !important;
    }

    .course-outline-nav {
      display: flex;
      border-radius: 12px;
      overflow: hidden;
      background: white;
      box-shadow: 0 3px 6px rgba(0,0,0,0.1);
      border: 1px solid #ddd;
    }

    .course-outline-nav .nav-btn {
      background: none;
      border: none;
      padding: 10px 16px;
      font-size: 1rem;
      transition: all 0.2s ease-in-out;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .course-outline-nav .nav-btn:hover {
      background-color: #f7f7f7;
      transform: scale(1.05);
    }

    .course-outline-btn {
      border-left: 1px solid #ddd;
      border-right: 1px solid #ddd;
      font-weight: 600;
      font-size: 0.95rem;
      letter-spacing: 0.5px;
      padding: 10px 20px;
    }

    .course-outline-btn:hover {
      background-color: #fff8d0;
    }

    h4 {
      font-family: 'Poppins', sans-serif;
      color: #333;
    }

    .badge {
      font-weight: 600;
      border-radius: 12px;
    }

    .show-module-btn {
      border-radius: 12px;
      font-weight: 600;
      padding: 10px 20px;
      font-size: 1rem;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
      transition: all 0.3s ease-in-out;
      border-width: 2px;
      background-color: #4D44DB;
      color: white;
      border: none;
    }

    .show-module-btn:hover {
      background-color: #3a32a8;
      color: white;
      transform: translateY(-2px);
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.25);
    }

    .module-content {
      max-height: 0;
      opacity: 0;
      overflow: hidden;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,.08);
      transition: max-height 0.4s ease, opacity 0.3s ease, padding 0.3s ease;
      padding: 0 16px;
      border: none;
    }

    .module-content.open {
      max-height: 600px;
      opacity: 1;
      padding: 16px;
      border: 1px solid #ddd;
    }

    .modal-content {
      border-radius: 16px;
      font-family: 'Poppins', sans-serif;
    }

    .modal-header {
      background-color: #f6db65;
      border-bottom: none;
    }

    .modal-title {
      color: #2D3748;
    }

    .progress {
      background-color: #fce47b;
      border-radius: 12px;
      overflow: hidden;
    }

    .list-group-item {
      font-weight: 500;
      border: none;
      padding: 14px 18px;
      cursor: pointer;
    }

    .list-group-item:nth-child(odd) {
      background-color: #fffdf0;
    }

    .progress-bar {
      transition: width 1s ease-in-out;
    }

    .list-group-item.active {
      background-color: #f0f8ff;
      color: #000;
      font-weight: bold;
      border-left: 4px solid #0d6efd;
    }
    .list-group-item.active span {
      color: #ffc107 !important;
    }

    pre {
      background-color: #f8f9fa;
      padding: 15px;
      border-radius: 5px;
      overflow-x: auto;
    }

    code {
      color: #d63384;
    }

    .btn-next-level {
      background-color: #4D44DB;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 8px;
      font-weight: 600;
    }
    
    .btn-next-level:disabled {
      background-color: #ccc;
      cursor: not-allowed;
    }
    
    .btn-next-level:hover:not(:disabled) {
      background-color: #3a32a8;
    }
  </style>
</head>
<body>
  <!-- Original Navbar from modules.html -->
  <nav class="navbar navbar-expand-lg top-nav sticky-top navbar-dark" role="navigation" aria-label="Main navigation">
    <div class="container-fluid d-flex justify-content-between align-items-center">
      <!-- Logo -->
      <a class="navbar-brand" href="dashboard.php">
        <img src="assets/logo.png" alt="Tiny Tech Logo" class="logo-img">
      </a>

      <!-- Hamburger -->
      <button class="navbar-toggler ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Collapsible Content -->
      <div class="collapse navbar-collapse justify-content-between" id="navbarContent">
        <!-- Centered Nav Links -->
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0 text-center">
          <!-- Mobile Profile Dropdown -->
          <li class="nav-item dropdown d-lg-none mb-2">
            <a class="fw-bold nav-link dropdown-toggle text-white" href="#" id="mobileProfileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?php echo !empty($user['profile_image_url']) ? htmlspecialchars($user['profile_image_url']) : 'assets/user-profile.jpg'; ?>" alt="Profile" class="rounded-circle me-2" width="24" height="24">
              <?php echo htmlspecialchars($user['username']); ?>
            </a>
            <ul class="dropdown-menu" aria-labelledby="mobileProfileDropdown">
              <li><a class="dropdown-item" href="user-profile.php">Profile</a></li>
              <li><a class="dropdown-item" href="#">Progress</a></li>
              <li><a class="dropdown-item" href="#">Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="logout.php">Sign Out</a></li>
            </ul>
          </li>
        </ul>
      </div>

      <div class="collapse navbar-collapse d-flex align-items-center w-100">
        <!-- Left Spacer (keeps center aligned perfectly) -->
        <div class="flex-grow-1"></div>

        <!-- Centered Course Outline Buttons -->
        <div class="d-flex justify-content-center">
          <div class="course-outline-nav d-flex align-items-center">
            <button class="nav-btn prev-btn" id="prevTopicBtn">
              <i class="bi bi-arrow-left"></i>
            </button>

            <!-- Course Outline Button with modal trigger -->
            <button class="nav-btn course-outline-btn fw-bold" data-bs-toggle="modal" data-bs-target="#courseOutlineModal">
              <i class="bi bi-list me-2"></i> Course Outline
            </button>

            <button class="nav-btn next-btn" id="nextTopicBtn">
              <i class="bi bi-arrow-right"></i>
            </button>
          </div>
        </div>

        <!-- Right Side: Profile Dropdown -->
        <div class="flex-grow-1 d-flex justify-content-end">
          <div class="dropdown">
            <a class="d-flex align-items-center gap-2 text-white text-decoration-none dropdown-toggle"
               href="#" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?php echo !empty($user['profile_image_url']) ? htmlspecialchars($user['profile_image_url']) : 'assets/user-profile.jpg'; ?>" alt="Profile" class="rounded-circle" width="32" height="32">
              <span class="fw-bold"><?php echo htmlspecialchars($user['username']); ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
              <li><a class="dropdown-item" href="user-profile.php">Profile</a></li>
              <li><a class="dropdown-item" href="#">Progress</a></li>
              <li><a class="dropdown-item" href="#">Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="logout.php">Sign Out</a></li>
            </ul>
          </div>
        </div>
      </div> <!-- closes parent flex container -->
    </div>
  </nav>

  <!-- Course Outline Modal -->
  <div class="modal fade" id="courseOutlineModal" tabindex="-1" aria-labelledby="courseOutlineModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content rounded-4 shadow-sm border-0">

        <!-- Header -->
        <div class="modal-header border-0 pb-0">
          <h5 class="modal-title fw-bold" id="courseOutlineModalLabel">
            <?php echo isset($courseMapping[$courseId]) ? $courseMapping[$courseId]['title'] : 'Course Outline'; ?>
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <!-- Body -->
        <div class="modal-body pt-2">
          <!-- Course description -->
          <?php if ($courseData): ?>
          <div class="mb-3">
            <p><?php echo htmlspecialchars($courseData['modules'][0]['description']); ?></p>
          </div>
          <?php endif; ?>
          
          <!-- Progress summary -->
          <div class="alert alert-info mb-3">
            <strong>Progress:</strong> <?php echo $completedModules; ?> out of <?php echo $totalModules; ?> modules completed
            <?php if ($allModulesCompleted): ?>
            <br><strong>Status:</strong> Course completed! 🎉
            <?php endif; ?>
          </div>
          
          <!-- Topics list -->
          <div class="list-group">
            <?php if ($courseData && isset($courseData['modules'][0]['topics'])): ?>
              <?php foreach ($courseData['modules'][0]['topics'] as $index => $topic): ?>
              <?php 
              $isCompleted = isset($_SESSION['course_progress'][$courseId][$index]);
              ?>
              <a href="modules.php?course=<?php echo $courseId; ?>&topic=<?php echo $index; ?>" 
                 class="list-group-item list-group-item-action <?php echo $index == $topicId ? 'active' : ''; ?>">
                <div class="d-flex w-100 justify-content-between">
                  <h6 class="mb-1">
                    <?php if ($isCompleted): ?>
                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                    <?php else: ?>
                    <i class="bi bi-circle me-2"></i>
                    <?php endif; ?>
                    <?php echo htmlspecialchars($topic['title']); ?>
                  </h6>
                  <small>50 XP</small>
                </div>
                <?php if ($isCompleted): ?>
                <small class="text-success"><i class="bi bi-check"></i> Completed</small>
                <?php endif; ?>
              </a>
              <?php endforeach; ?>
            <?php else: ?>
              <p>No topics available for this course.</p>
            <?php endif; ?>
          </div>
        </div>

        <!-- Footer -->
        <div class="modal-footer border-0">
          <button type="button" class="btn btn-outline-dark fw-bold px-4" onclick="window.location.href='dashboard.php'">
            Back to Dashboard
          </button>
          
          <!-- Next Level Button Form -->
          <form method="POST" class="d-inline">
            <button type="submit" name="next_level" class="btn btn-next-level fw-bold px-4" 
                    id="nextLevelBtn" <?php echo $allModulesCompleted ? '' : 'disabled'; ?>>
              <?php 
              $nextCourseId = isset($courseMapping[$courseId]['next_course']) ? $courseMapping[$courseId]['next_course'] : null;
              if ($nextCourseId) {
                  echo 'Next Course: ' . $courseMapping[$nextCourseId]['title'];
              } else {
                  echo 'Back to Dashboard';
              }
              ?>
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="container mb-5" style="margin-top: 80px; max-width: 1150px;">
    <!-- Title + XP Row -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="fw-bold text-black m-0" id="topicTitle">
        <?php echo $currentTopic ? htmlspecialchars($currentTopic['title']) : 'Loading Topic...'; ?>
      </h4>
      <span class="badge bg-warning text-dark fs-6 shadow-sm px-3 py-2">50 XP</span>
    </div>

    <!-- Video -->
    <div class="d-flex justify-content-center">
      <?php if ($currentTopic && !empty($currentTopic['videoUrl'])): ?>
      <video controls class="shadow-lg rounded-4 w-100" id="topicVideo">
        <source src="<?php echo htmlspecialchars($currentTopic['videoUrl']); ?>" type="video/mp4">
        Your browser does not support the video tag.
      </video>
      <?php else: ?>
      <div class="alert alert-info w-100 text-center">
        Video content not available for this topic.
      </div>
      <?php endif; ?>
    </div>

    <!-- Show/Hide Button -->
    <div class="d-flex justify-content-start mt-3">
      <button type="button" class="btn show-module-btn" onclick="toggleModule()">
        📑 Show Module
      </button>
    </div>

    <!-- Module Content (hidden by default) -->
    <div id="moduleContent" class="module-content shadow-lg mt-3">
      <h5 class="fw-bold mb-3" id="moduleTitle">
        <?php echo $currentTopic ? htmlspecialchars($currentTopic['title']) : 'Loading Topic...'; ?>
      </h5>
      <div id="moduleDescription">
        <?php if ($currentTopic): ?>
        <p><?php echo htmlspecialchars($currentTopic['description']); ?></p>
        <?php if (!empty($currentTopic['codeExample'])): ?>
        <pre><code><?php echo htmlspecialchars($currentTopic['codeExample']); ?></code></pre>
        <?php endif; ?>
        <?php else: ?>
        <p>Loading content...</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Toast Notification Script -->
  <script src="toast.js"></script>

  <script>
    // Toggle module content visibility
    function toggleModule() {
      const moduleContent = document.getElementById('moduleContent');
      const button = document.querySelector('.show-module-btn');

      moduleContent.classList.toggle('open');
      if (moduleContent.classList.contains('open')) {
        button.textContent = "🙈 Hide Module";
      } else {
        button.textContent = "📑 Show Module";
      }
    }

    // Navigation between topics
    document.getElementById('prevTopicBtn').addEventListener('click', function() {
      const currentTopic = <?php echo $topicId; ?>;
      if (currentTopic > 0) {
        window.location.href = `modules.php?course=<?php echo $courseId; ?>&topic=${currentTopic - 1}`;
      }
    });

    document.getElementById('nextTopicBtn').addEventListener('click', function() {
      const currentTopic = <?php echo $topicId; ?>;
      const maxTopic = <?php echo $courseData ? count($courseData['modules'][0]['topics']) - 1 : 0; ?>;
      if (currentTopic < maxTopic) {
        window.location.href = `modules.php?course=<?php echo $courseId; ?>&topic=${currentTopic + 1}`;
      }
    });

    // Initialize when page loads
    document.addEventListener('DOMContentLoaded', function() {
      // Update next level button state based on PHP condition
      const nextLevelBtn = document.getElementById('nextLevelBtn');
      const allModulesCompleted = <?php echo $allModulesCompleted ? 'true' : 'false'; ?>;
      
      if (allModulesCompleted) {
        nextLevelBtn.disabled = false;
        nextLevelBtn.title = "Proceed to the next level";
      } else {
        nextLevelBtn.disabled = true;
        nextLevelBtn.title = "Complete all " + <?php echo $totalModules; ?> + " modules to unlock the next level";
      }
      
      // Update navigation buttons state
      const currentTopic = <?php echo $topicId; ?>;
      const maxTopic = <?php echo $courseData ? count($courseData['modules'][0]['topics']) - 1 : 0; ?>;
      
      document.getElementById('prevTopicBtn').disabled = currentTopic <= 0;
      document.getElementById('nextTopicBtn').disabled = currentTopic >= maxTopic;
      
      // Auto-play video when page loads
      const video = document.getElementById('topicVideo');
      if (video) {
        video.play().catch(function(error) {
          // Autoplay was prevented, but that's okay
          console.log('Video autoplay prevented:', error);
        });
      }
    });
  </script>
</body>
</html>