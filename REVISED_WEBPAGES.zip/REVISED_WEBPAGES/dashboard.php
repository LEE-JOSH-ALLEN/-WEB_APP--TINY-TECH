<?php
session_start();
require_once 'auth.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id']) || !validateUserSession($_SESSION['user_id'])) {
    header("Location: login-page.php");
    exit;
}

// Get user data
$user = getUserById($_SESSION['user_id']);

// Check for toast message
$toastMessage = '';
$toastType = 'success';
if (isset($_SESSION['toast_message'])) {
    $toastMessage = $_SESSION['toast_message'];
    $toastType = $_SESSION['toast_type'] ?? 'success';
    unset($_SESSION['toast_message']);
    unset($_SESSION['toast_type']);
}

//Setting completedModules variable
$course_1 = 1;
$course_2 = 2;
$course_3 = 3;
$course_4 = 4;
$course_5 = 5;
$course_6 = 6;

$completedModules_1 = isset($_SESSION['course_progress'][$course_1]) ? count($_SESSION['course_progress'][$course_1]) : 0;
$completedModules_2 = isset($_SESSION['course_progress'][$course_2]) ? count($_SESSION['course_progress'][$course_2]) : 0;
$completedModules_3 = isset($_SESSION['course_progress'][$course_3]) ? count($_SESSION['course_progress'][$course_3]) : 0;
$completedModules_4 = isset($_SESSION['course_progress'][$course_4]) ? count($_SESSION['course_progress'][$course_4]) : 0;
$completedModules_5 = isset($_SESSION['course_progress'][$course_5]) ? count($_SESSION['course_progress'][$course_5]) : 0;
$completedModules_6 = isset($_SESSION['course_progress'][$course_6]) ? count($_SESSION['course_progress'][$course_6]) : 0;

$lesson_val = $completedModules_1+$completedModules_2+$completedModules_3+$completedModules_4+$completedModules_5+$completedModules_6;
$completedCourse = 0;

if ($completedModules_1 == 5){
  $completedCourse += 1;
}
if ($completedModules_6 == 8){
  $completedCourse += 1;
}
if ($completedModules_5 == 6){
  $completedCourse += 1;
}
if ($completedModules_4 == 14){
  $completedCourse += 1;
}
if ($completedModules_3 == 11){
  $completedCourse += 1;
}
if ($completedModules_2 == 5){
  $completedCourse += 1;
}

//Last visited module
$lastVisited = isset($_SESSION['last_visited']) ? $_SESSION['last_visited'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Tiny Tech - Dashboard</title>

  <!-- Bootstrap + Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Press+Start+2P&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <!-- Your Styles -->
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <!-- ===== NAVBAR ===== -->
  <nav class="navbar navbar-expand-lg top-nav sticky-top navbar-dark">
    <div class="container-fluid d-flex justify-content-between align-items-center">
      <!-- Logo -->
      <a class="navbar-brand" href="dashboard.php">
        <img src="logo.png" alt="Tiny Tech Logo" class="logo-img">
      </a>

      <!-- Mobile Search -->
      <div class="d-lg-none d-flex align-items-center gap-2">
        <input class="form-control form-control-sm search-input-mobile" type="search" placeholder="Search" aria-label="Search">
      </div>

      <!-- Hamburger -->
      <button class="navbar-toggler ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Collapsible -->
      <div class="collapse navbar-collapse justify-content-between" id="navbarContent">
        <!-- Links -->
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0 text-center">
          <li class="nav-item"><a class="fw-bold nav-link" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="fw-bold nav-link" href="roadmap.php">Explore</a></li>
          <li class="nav-item"><a class="fw-bold nav-link" href="#">Ideas</a></li>
          <li class="nav-item"><a class="fw-bold nav-link" href="about.php">About</a></li>
        </ul>

        <!-- Desktop Search + Profile -->
        <form class="d-none d-lg-flex align-items-center gap-2" role="search">
          <input class="form-control form-control-sm search-input" type="search" placeholder="Search..." aria-label="Search">
          <div class="dropdown">
            <a class="d-flex align-items-center gap-2 text-decoration-none dropdown-toggle profile-link" href="#" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?php echo !empty($user['profile_image_url']) ? htmlspecialchars($user['profile_image_url']) : 'user-profile.png'; ?>" alt="user-profile.png" class="rounded-circle" width="32" height="32">
              <span class="fw-bold"><?php echo htmlspecialchars($user['username']); ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
              <li><a class="dropdown-item" href="user-profile.php">Profile</a></li>
              <li><a class="dropdown-item" href="#">Progress</a></li>
              <li><a class="dropdown-item" href="#">Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="logout.php">Sign Out</a></li>
            </ul>
          </div>
        </form>
      </div>
    </div>
  </nav>

  <!-- ===== MAIN CONTENT ===== -->
  <div class="container py-4">
    <!-- Welcome + Progress Badges -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
      <h2 class="welcome-text mb-3 mb-md-0">Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h2>
    </div>

    <!-- ===== Current Module Progress ===== -->
    <div class="progress-card mb-4">
      <div class="progress-card-body">
        <!-- Header -->
        <div class="d-flex justify-content-between flex-wrap align-items-center mb-4">
          <h5 class="progress-card-title">Current Module: <?php echo $lastVisited['course_title']; ?></h5>
          <div class="d-flex gap-4">
            <div class="text-center">
              <small class="progress-subtext">Time Spent</small>
              <h6 class="progress-highlight">1h 24m</h6>
            </div>
            <div class="text-center">
              <small class="progress-subtext">Mastery</small>
              <h6 class="progress-highlight">Beginner</h6>
            </div>
          </div>
        </div>

        <!-- Progress -->
        <div class="progress custom-progress mb-3">
          <div class="progress-bar" role="progressbar" style="width:<?php echo $lesson_val / 49 * 100; ?>%" aria-valuenow="<?php echo $lesson_val / 49 * 100; ?>" aria-valuemin="0" aria-valuemax="100">
            <?php echo round($lesson_val / 49 * 100, 0); ?>%
          </div>
        </div>

        <!-- Footer Info -->
        <div class="d-flex justify-content-between">
          <small class="progress-subtext">Module <?php echo $completedCourse; ?> of 6</small>
        </div>
      </div>
    </div>

    <!-- ===== Course Modules (6 cards) ===== -->
    <div class="row gy-4 mb-5">
      <!-- Module cards would be dynamically generated from database in a real application -->
          <!-- ===== Course Modules (6 cards) ===== -->
            <div class="row gy-4 mb-5">
              <div class="col-md-4">
                <div class="course-card h-100">
                  <span class="course-label">Module 1</span>
                  <h5 class="course-title">Python Basics</h5>
                  <p class="course-text">
                    Learn the basics of programming, syntax, and problem-solving...
                  </p>
                  <span class="course-badge">Beginner</span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="course-card h-100" onclick="location.href=''">
                  <span class="course-label">Module 2</span>
                  <h5 class="course-title">Control Flow</h5>
                  <p class="course-text">
                    Learn programming fundamentals such as variables, control flow, and loops...
                  </p>
                  <span class="course-badge">Beginner</span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="course-card h-100" onclick="location.href=''">
                  <span class="course-label">Module 3</span>
                  <h5 class="course-title">Data Structures</h5>
                  <p class="course-text">
                    Learn programming fundamentals such as variables, control flow, and loops...
                  </p>
                  <span class="course-badge">Beginner</span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="course-card h-100" onclick="location.href=''">
                  <span class="course-label">Module 4</span>
                  <h5 class="course-title">Functions</h5>
                  <p class="course-text">
                    Learn programming fundamentals such as variables, control flow, and loops...
                  </p>
                  <span class="course-badge">Beginner</span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="course-card h-100" onclick="location.href=''">
                  <span class="course-label">Module 5</span>
                  <h5 class="course-title">Error Handling & Files</h5>
                  <p class="course-text">
                    Learn programming fundamentals such as variables, control flow, and loops...
                  </p>
                  <span class="course-badge">Beginner</span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="course-card h-100" onclick="location.href=''">
                  <span class="course-label">Module 6</span>
                  <h5 class="course-title">Advanced Fundamentals</h5>
                  <p class="course-text">
                    Learn programming fundamentals such as variables, control flow, and loops...
                  </p>
                  <span class="course-badge">Beginner</span>
                </div>
              </div>
            </div>
    </div>

    <!-- ===== Learning Path + Analytics ===== -->
    <div class="row gy-4">
      <!-- LEFT: Leaderboard -->
      <div class="col-lg-6">
        <div class="card-dark h-100">
          <div class="card-body">
            <h5 class="text-white mb-3">Community Leaderboard</h5>
            
            <!-- Leaderboard items would be dynamically generated from database -->
            <div class="leaderboard-item d-flex align-items-center">
              <div class="leaderboard-rank">1</div>
              <img src="https://i.pravatar.cc/40?img=1" alt="Avatar" class="leaderboard-avatar">
              <div class="flex-grow-1 ms-3">
                <h6 class="mb-0 text-white">Alex Johnson</h6>
              </div>
              <div class="text-end">
                <h6 class="mb-0 text-white">950 pts</h6>
                <small class="text-success">+25 today</small>
              </div>
            </div>
            
            <!-- Additional leaderboard items... -->
          </div>
        </div>
      </div>

      <!-- RIGHT: Learning Path + Performance -->
      <div class="col-lg-6">
        <div class="row gy-4">
          <!-- Performance Metrics -->
          <div class="col-12">
            <div class="card-dark">
              <div class="card-body">
                <h5 class="text-white mb-3">Performance Metrics</h5>
                <!-- Performance metrics would be dynamically generated from database -->
                <div class="metric-item mb-3">
                  <div class="d-flex justify-content-between">
                    <small>Code Accuracy</small><small>85%</small>
                  </div>
                  <div class="progress progress-bar-custom">
                    <div class="progress-bar bg-success" style="width: 85%"></div>
                  </div>
                </div>
                <!-- Additional metrics... -->
              </div>
            </div>
          </div>

          <!-- Learning Path -->
          <div class="col-12">
            <div class="card-dark">
              <div class="card-body">
                <h5 class="text-white mb-4">Python Learning Path</h5>
                <!-- Learning path items would be dynamically generated from database -->
                <div class="module-item mb-3">
                  <div class="d-flex justify-content-between">
                    <span class="fw-bold text-white">Module 1: Python Basics</span>
                    <span class="status-badge completed">Completed</span>
                  </div>
                  <small class="text-muted">Variables, Data Types, Operators</small>
                </div>
                <!-- Additional learning path items... -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- ===== Footer ===== -->
  <footer class="footer-dark mt-5">
    <div class="container py-5">
      <div class="row gy-4">
        <!-- Brand -->
        <div class="col-lg-4">
          <h4 class="text-white fw-bold">Tiny Tech</h4>
          <p class="text-white-50">
            Empowering learners with modern tech skills and hands-on coding experience.
          </p>
        </div>

        <!-- Quick Links -->
        <div class="col-lg-4">
          <h6 class="text-white fw-bold mb-3">Quick Links</h6>
          <ul class="list-unstyled">
            <li><a href="#" class="footer-link">About Us</a></li>
            <li><a href="#" class="footer-link">Contact</a></li>
            <li><a href="#" class="footer-link">Privacy Policy</a></li>
            <li><a href="#" class="footer-link">Terms of Service</a></li>
          </ul>
        </div>

        <!-- Social Media -->
        <div class="col-lg-4">
          <h6 class="text-white fw-bold mb-3">Connect With Us</h6>
            <div class="d-flex gap-3">
              <a href="#" class="social-icon">
                <img src="assets/facebook.png" alt="Facebook">
              </a>
              <a href="#" class="social-icon">
                <img src="assets/x.png" alt="Twitter">
              </a>
              <a href="#" class="social-icon">
                <img src="assets/linkedin.png" alt="LinkedIn">
              </a>
              <a href="#" class="social-icon">
                <img src="assets/github.png" alt="GitHub">
              </a>
            </div>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  
  <!-- Toast Notification Script -->
  <script src="toast.js"></script>
  
  <?php if ($toastMessage): ?>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      showToast('<?php echo $toastMessage; ?>', '<?php echo $toastType; ?>');
    });
  </script>
  <?php endif; ?>
</body>
</html>