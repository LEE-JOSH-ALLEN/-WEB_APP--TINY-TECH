-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2025 at 11:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tinytech_db`
--
CREATE DATABASE IF NOT EXISTS `tinytech_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tinytech_db`;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `total_modules` int(11) DEFAULT NULL,
  `estimated_duration` int(11) DEFAULT NULL,
  `difficulty_level` enum('beginner','intermediate','advanced') DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `description`, `total_modules`, `estimated_duration`, `difficulty_level`, `is_active`) VALUES
(2, 'Python Basics', 'In this chapter, you\'ll learn the basics of Python programming. We\'ll cover how to display information with the print() function, store values using variables, and work with common data types such as integers, floats, strings, and booleans. You\'ll also explore Python\'s operators for calculations, assignments, and comparisons, as well as how to accept user input and convert it into the right type. Finally, we\'ll introduce simple debugging techniques to help you understand error messages and fix common mistakes. By the end, you\'ll have the essential foundation to start writing and testing your own Python programs.', 5, 10, 'beginner', 1),
(3, 'Control Flow', 'In this chapter, you\'ll learn about control flow in Python. We\'ll cover how to use if statements, elif, else, and logical operators to guide program decisions. By the end, you\'ll be able to control the order of execution in your code and make it respond to different conditions effectively.', 5, 10, 'beginner', 1),
(4, 'Lists', 'In this module, you\'ll learn about lists in Python - ordered, mutable collections that allow duplicate elements.', 11, 10, 'beginner', 0),
(5, 'Functions', 'Discover how functions make Python code easier to write and reuse! You\'ll practice creating and calling functions, using parameters and arguments, and returning values. You\'ll also explore how variable scope works, from local to global, and learn how the global keyword affects your code. By the end, you\'ll know how to build cleaner and more efficient programs with functions.', 14, 10, 'beginner', 0),
(6, 'Error Handling and Files', 'In this module, you\'ll learn about error handling in Python - how to gracefully handle exceptions and work with files.', 6, 10, 'beginner', 0),
(7, 'Modules and Importation', 'In this module, you\'ll learn about Python modules - how to create them, import them, and work with built-in modules.', 8, 10, 'beginner', 0);

-- --------------------------------------------------------

--
-- Table structure for table `exercises`
--

DROP TABLE IF EXISTS `exercises`;
CREATE TABLE `exercises` (
  `exercise_id` int(11) NOT NULL,
  `module_id` int(11) DEFAULT NULL,
  `exercise_type` enum('quiz','coding','drag_drop') NOT NULL,
  `question_text` text DEFAULT NULL,
  `code_template` text DEFAULT NULL,
  `correct_answer` text DEFAULT NULL,
  `xp_value` int(11) DEFAULT 10,
  `hint_text` text DEFAULT NULL,
  `hint_xp_cost` int(11) DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `module_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `order_number` int(11) DEFAULT NULL,
  `estimated_duration` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`module_id`, `course_id`, `module_name`, `description`, `order_number`, `estimated_duration`, `is_active`) VALUES
(2, 2, 'Print Statements', 'The print() function prints the specified message to the screen, or other standard output device. The message can be a string, or any other object, the object will be converted into a string before being written to the screen.', 1, 2, 1),
(3, 2, 'Variables and Data Types', 'Variables are containers for storing data values. Python has no command for declaring a variable. A variable is created the moment you first assign a value to it.', 2, 2, 1),
(4, 2, 'Basic Operators', 'Operators are used to perform operations on variables and values. There are three types of Operators which are Arithmetic Operators, Assignment Operators, and Comparison Operators.', 3, 2, 1),
(5, 2, 'User Input Handling', 'If the prompt argument is present, it is written to standard output without a trailing newline. The function then reads a line from input, converts it to a string (stripping a trailing newline), and returns that.', 4, 2, 0),
(6, 2, 'Simple Debugging', 'There are (at least) two distinguishable kinds of errors: syntax errors and exceptions. Syntax errors, also known as parsing errors, are perhaps the most common kind of complaint you get while you are still learning Python.', 5, 2, 0),
(7, 3, 'Conditional Statements', 'Python supports the usual logical conditions from mathematics. These conditions can be used in several ways, most commonly in if statements and loops. An if statement is written by using the if keyword.', 1, 2, 1),
(8, 3, 'Logical Operators', 'Logical operators are used to combine conditional statements in Python.', 2, 2, 0),
(9, 3, 'Looping', 'Python has two primitive loop commands: while loops and for loops. Loops allow you to repeat a block of code multiple times until a condition is met.', 3, 2, 0),
(10, 3, 'Loop Control Statements', 'A for loop is used for iterating over a sequence. It executes a block of code once for each item in the sequence.', 4, 2, 0),
(11, 3, 'Nested Control Structures', 'Python allows loops inside loops, known as nested loops. The \'inner loop\' runs once for each iteration of the \'outer loop\'.', 5, 2, 0),
(12, 4, 'List Creation', 'Lists are created using square brackets. They can contain any data type and can be modified after creation.', 1, 2, 0),
(13, 4, 'List Properties', 'Lists are ordered, changeable, and allow duplicate values. Items have a defined sequence that is preserved.', 2, 2, 0),
(14, 4, 'List Indexing', 'Lists support both positive indexing (starting at 0) and negative indexing (starting at -1 for the last element).', 3, 2, 0),
(15, 4, 'List Length', 'Use the len() function to get the number of items in a list.', 4, 2, 0),
(16, 4, 'Data Types in Lists', 'Lists can contain any data type or a mix of different data types.', 5, 2, 0),
(17, 4, 'Accessing List Items', 'Access ranges of items using slicing [start:end] and check if an item exists using the \'in\' keyword.', 6, 2, 0),
(18, 4, 'Modifying Lists', 'Change items by assigning to a specific index or change a range of items by assigning to a slice.', 7, 2, 0),
(19, 4, 'Adding List Items', 'Add items to a list using append(), insert(), or extend() methods.', 8, 2, 0),
(20, 4, 'Removing List Items', 'Remove items from a list using remove(), pop(), or clear() methods.', 9, 2, 0),
(21, 4, 'Looping Through Lists', 'Iterate through lists using for loops or create new lists with list comprehensions.', 10, 2, 0),
(22, 4, 'List Methods', 'Python provides several built-in methods to work with lists, including append(), clear(), copy(), count(), extend(), index(), insert(), pop(), remove(), reverse(), and sort().', 11, 2, 0),
(23, 5, 'Defining Functions', 'A function is a block of code which only runs when it is called. You can also pass data, known as parameters, into a function. A function can return data as a result.', 1, 2, 0),
(24, 5, 'Creating a Function', 'In Python, a function is defined using the def keyword followed by the function name and parentheses.', 2, 2, 0),
(25, 5, 'Calling a Function', 'To call a function, use the function name followed by parentheses. This executes the code inside the function.', 3, 2, 0),
(26, 5, 'Parameters and Arguments', 'The terms parameter and argument can be used for the same thing: information that is passed into a function. From a function\'s perspective, a parameter is the variable listed inside the parentheses, while an argument is the value sent to the function.', 4, 2, 0),
(27, 5, 'Parameters', 'A parameter is the variable listed inside the parentheses in the function definition. It acts as a placeholder for the actual value that will be passed when the function is called.', 5, 2, 0),
(28, 5, 'Arguments', 'An argument is the value that is sent to the function when it is called. Arguments are the actual values that replace the parameters when the function executes.', 6, 2, 0),
(29, 5, 'Return Values and None', 'A return statement is used to end the execution of the function call and returns the value of the expression following the return keyword to the caller. If no expression is provided, the special value None is returned.', 7, 2, 0),
(30, 5, 'Return', 'The return statement ends function execution and specifies a value to be returned to the function caller. Statements after a return statement are not executed.', 8, 2, 0),
(31, 5, 'None', 'None is a special value in Python that represents the absence of a value. Functions without an explicit return statement automatically return None.', 9, 2, 0),
(32, 5, 'Variable Scope', 'A variable is only available from inside the region it is created. This is called scope. Python has local scope (inside functions) and global scope (outside functions).', 10, 2, 0),
(33, 5, 'Local Scope', 'A variable created inside a function belongs to the local scope of that function, and can only be used inside that function.', 11, 2, 0),
(34, 5, 'Global Scope', 'A variable created in the main body of the Python code is a global variable and belongs to the global scope. Global variables are available from within any scope, both global and local.', 12, 2, 0),
(35, 5, 'Naming Variables', 'If you operate with the same variable name inside and outside of a function, Python will treat them as two separate variables: one in the global scope and one in the local scope.', 13, 2, 0),
(36, 5, 'Global Keyword', 'If you need to create a global variable inside a function, you can use the global keyword. The global keyword makes the variable belong to the global scope.', 14, 2, 0),
(37, 6, 'Exception Handling', 'Python Exception Handling handles errors that occur during the execution of a program. It allows the user to respond to errors instead of crashing the running program. This makes code more robust and user-friendly.', 1, 2, 0),
(38, 6, 'Simple Exception Handling', 'Basic exception handling using try and except blocks to catch and handle specific errors.', 2, 2, 0),
(39, 6, 'Handling Multiple Exceptions', 'How to handle different types of exceptions with multiple except blocks.', 3, 2, 0),
(40, 6, 'Exception Using Else', 'Using the else block to execute code when no errors occur in the try block.', 4, 2, 0),
(41, 6, 'Exception Using Finally', 'Using the finally block to execute code regardless of whether an exception occurred or not.', 5, 2, 0),
(42, 6, 'Built-in Exception Types', 'Python provides several built-in exceptions that are raised automatically when errors occur. These exceptions help identify the type of error in the code.', 6, 2, 0),
(43, 7, 'What is a Module?', 'A module is a code library containing a set of functions you want to include in your application. It\'s a file with a .py extension.', 1, 2, 0),
(44, 7, 'Create a Module', 'To create a module, save the code you want in a file with the .py extension.', 2, 2, 0),
(45, 7, 'Import a Module', 'Use the import statement to include a module in your application.', 3, 2, 0),
(46, 7, 'Variables in Module', 'Modules can contain functions as well as variables of all types (arrays, dictionaries, objects, etc.).', 4, 2, 0),
(47, 7, 'Naming a Module', 'You can name the module file anything you want, but it must have the file extension .py.', 5, 2, 0),
(48, 7, 'Re-naming a Module', 'You can create an alias when you import a module using the as keyword.', 6, 2, 0),
(49, 7, 'Built-in Modules', 'Python comes with several built-in modules that you can import whenever you like.', 7, 2, 0),
(50, 7, 'Import From Module', 'You can choose to import only parts from a module using the from keyword.', 8, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `xp_points` int(11) DEFAULT 0,
  `current_level` int(11) DEFAULT 1,
  `account_status` enum('active','inactive') DEFAULT 'active',
  `is_logged_in` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `full_name`, `phone`, `location`, `profile_image_url`, `created_at`, `last_login`, `xp_points`, `current_level`, `account_status`, `is_logged_in`) VALUES
(1, 'john_doe88', 'john.doe@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', NULL, NULL, 'https://example.com/profiles/john.jpg', '2023-01-15 01:30:45', '2025-08-26 10:52:49', 4500, 5, 'active', 0),
(2, 'sarah_miller', 'sarah.m@mail.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sarah Miller', NULL, NULL, NULL, '2023-02-18 03:20:15', '2025-09-17 09:33:41', 1200, 2, 'active', 0),
(3, 'mike_jones23', 'mike.jones@web.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Mike Jones', NULL, NULL, 'https://example.com/profiles/mike.png', '2023-03-05 08:45:22', NULL, 800, 1, 'active', 0),
(4, 'lisa_wang42', 'lisa.wang@mail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Lisa Wang', NULL, NULL, 'https://example.com/profiles/lisa.jpg', '2023-07-12 00:20:33', '2023-08-22 01:45:11', 6700, 7, 'active', 0),
(5, 'david_smith', 'david.smith@email.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'David Smith', NULL, NULL, NULL, '2023-04-10 00:15:40', '2023-08-18 04:30:15', 2500, 3, 'inactive', 0),
(208, 'emma_wilson', 'emma.wilson@domain.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Emma Wilson', NULL, NULL, 'https://example.com/profiles/emma.jpg', '2023-01-22 06:33:10', '2023-08-19 08:45:22', 7800, 8, 'active', 0),
(209, 'lisa_jackson', 'lisa.jackson@web.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Lisa Jackson', NULL, NULL, 'https://example.com/profiles/lisa.png', '2023-02-28 09:22:33', '2023-08-22 01:15:27', 9200, 9, 'active', 0),
(210, 'robert_brown', 'robert.b@mail.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Robert Brown', NULL, NULL, 'https://example.com/profiles/robert.jpg', '2023-05-15 02:40:55', NULL, 300, 1, 'active', 0),
(211, 'susan_davis', 'susan.davis@domain.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Susan Davis', NULL, NULL, NULL, '2023-03-20 05:25:18', '2023-08-21 06:20:33', 6400, 7, 'active', 0),
(212, 'james_wilson', 'james.wilson@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'James Wilson', NULL, NULL, 'https://example.com/profiles/james.png', '2023-06-05 01:10:25', '2023-08-20 03:45:10', 1100, 2, 'active', 0),
(213, 'patricia_taylor', 'patricia.t@web.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Patricia Taylor', NULL, NULL, 'https://example.com/profiles/patricia.jpg', '2023-01-10 08:30:40', NULL, 5000, 5, 'inactive', 0),
(214, 'michael_clark', 'michael.c@mail.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Michael Clark', NULL, NULL, NULL, '2023-04-18 03:45:30', '2023-08-19 07:20:45', 8700, 9, 'active', 0),
(215, 'linda_martinez', 'linda.m@domain.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Linda Martinez', NULL, NULL, 'https://example.com/profiles/linda.png', '2023-02-05 06:20:15', '2023-08-22 02:30:20', 3200, 4, 'active', 0),
(216, 'william_lee', 'william.lee@email.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'William Lee', NULL, NULL, 'https://example.com/profiles/william.jpg', '2023-05-22 02:15:35', NULL, 200, 1, 'active', 0),
(217, 'elizabeth_white', 'elizabeth.w@web.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Elizabeth White', NULL, NULL, NULL, '2023-03-12 07:40:25', '2023-08-21 05:15:30', 7100, 7, 'active', 0),
(218, 'charles_hall', 'charles.hall@mail.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Charles Hall', NULL, NULL, 'https://example.com/profiles/charles.png', '2023-06-20 04:30:50', '2023-08-20 08:45:15', 4300, 5, 'active', 0),
(219, 'jennifer_king', 'jennifer.k@domain.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jennifer King', NULL, NULL, 'https://example.com/profiles/jennifer.jpg', '2023-01-28 01:45:20', NULL, 1500, 2, 'inactive', 0),
(220, 'thomas_young', 'thomas.y@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Thomas Young', NULL, NULL, NULL, '2023-04-05 08:20:40', '2023-08-19 06:10:25', 9800, 10, 'active', 0),
(221, 'mary_scott', 'mary.scott@web.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Mary Scott', NULL, NULL, 'https://example.com/profiles/mary.png', '2023-02-15 05:10:30', '2023-08-22 01:25:40', 5600, 6, 'active', 0),
(222, 'christopher_green', 'chris.green@mail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Christopher Green', NULL, NULL, 'https://example.com/profiles/chris.jpg', '2023-05-10 03:35:45', NULL, 900, 1, 'active', 0),
(223, 'nancy_adams', 'nancy.adams@domain.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Nancy Adams', NULL, NULL, NULL, '2023-03-25 06:50:15', '2023-08-21 07:35:20', 6700, 7, 'active', 0),
(224, 'daniel_baker', 'daniel.b@email.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Daniel Baker', NULL, NULL, 'https://example.com/profiles/daniel.png', '2023-06-12 02:25:35', '2023-08-20 04:40:55', 3800, 4, 'active', 0),
(225, 'karen_nelson', 'karen.nelson@web.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Karen Nelson', NULL, NULL, 'https://example.com/profiles/karen.jpg', '2023-01-18 07:40:20', NULL, 2200, 3, 'active', 0),
(226, 'matthew_carter', 'matthew.c@mail.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Matthew Carter', NULL, NULL, NULL, '2023-04-22 04:15:40', '2023-08-19 05:20:35', 8900, 9, 'inactive', 0),
(227, 'betty_mitchell', 'betty.m@domain.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Betty Mitchell', NULL, NULL, 'https://example.com/profiles/betty.png', '2023-02-08 01:30:25', '2023-08-22 03:15:50', 5400, 6, 'active', 0),
(228, 'anthony_perez', 'anthony.p@email.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anthony Perez', NULL, NULL, 'https://example.com/profiles/anthony.jpg', '2023-05-28 08:45:10', NULL, 700, 1, 'active', 0),
(229, 'helen_roberts', 'helen.r@web.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Helen Roberts', NULL, NULL, NULL, '2023-03-15 05:20:35', '2023-08-21 06:45:20', 7600, 8, 'active', 0),
(230, 'mark_turner', 'mark.turner@mail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Mark Turner', NULL, NULL, 'https://example.com/profiles/mark.png', '2023-06-25 03:10:45', '2023-08-20 07:30:35', 4100, 5, 'active', 0),
(231, 'sandra_phillips', 'sandra.p@domain.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sandra Phillips', NULL, NULL, 'https://example.com/profiles/sandra.jpg', '2023-01-05 06:35:20', NULL, 1800, 2, 'active', 0),
(232, 'donald_campbell', 'donald.c@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Donald Campbell', NULL, NULL, NULL, '2023-04-15 02:20:40', '2023-08-19 08:15:25', 9500, 10, 'active', 0),
(233, 'dorothy_parker', 'dorothy.p@web.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dorothy Parker', NULL, NULL, 'https://example.com/profiles/dorothy.png', '2023-02-22 09:15:30', '2023-08-22 02:20:45', 5900, 6, 'active', 0),
(234, 'paul_evans', 'paul.evans@mail.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Paul Evans', NULL, NULL, 'https://example.com/profiles/paul.jpg', '2023-05-05 00:40:15', NULL, 1200, 2, 'inactive', 0),
(235, 'carol_edwards', 'carol.e@domain.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Carol Edwards', NULL, NULL, NULL, '2023-03-08 07:25:50', '2023-08-21 04:30:15', 8300, 9, 'active', 0),
(236, 'george_collins', 'george.c@email.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'George Collins', NULL, NULL, 'https://example.com/profiles/george.png', '2023-06-15 04:10:25', '2023-08-20 06:45:30', 4700, 5, 'active', 0),
(237, 'ruth_stewart', 'ruth.s@web.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ruth Stewart', NULL, NULL, 'https://example.com/profiles/ruth.jpg', '2023-01-25 01:55:40', NULL, 2600, 3, 'active', 0),
(238, 'kevin_sanchez', 'kevin.s@mail.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Kevin Sanchez', NULL, NULL, NULL, '2023-04-28 08:30:15', '2023-08-19 03:20:40', 7200, 8, 'active', 0),
(239, 'sharon_morris', 'sharon.m@domain.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sharon Morris', NULL, NULL, 'https://example.com/profiles/sharon.png', '2023-02-12 05:45:30', '2023-08-22 01:35:45', 5100, 6, 'active', 0),
(240, 'brian_rogers', 'brian.r@email.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Brian Rogers', NULL, NULL, 'https://example.com/profiles/brian.jpg', '2023-05-18 02:20:45', NULL, 1000, 1, 'active', 0),
(241, 'michelle_reed', 'michelle.r@web.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Michelle Reed', NULL, NULL, NULL, '2023-03-28 06:35:20', '2023-08-21 07:50:35', 6800, 7, 'active', 0),
(242, 'edward_cook', 'edward.cook@mail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Edward Cook', NULL, NULL, 'https://example.com/profiles/edward.png', '2023-06-08 03:50:35', '2023-08-20 05:15:50', 3900, 4, 'active', 0),
(243, 'laura_bell', 'laura.b@domain.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Laura Bell', NULL, NULL, 'https://example.com/profiles/laura.jpg', '2023-01-12 08:15:10', NULL, 2100, 3, 'inactive', 0),
(244, 'ronald_murphy', 'ronald.m@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ronald Murphy', NULL, NULL, NULL, '2023-04-08 04:40:25', '2023-08-19 06:55:40', 9100, 9, 'active', 0),
(245, 'amanda_bailey', 'amanda.b@web.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Amanda Bailey', NULL, NULL, 'https://example.com/profiles/amanda.png', '2023-02-25 01:25:40', '2023-08-22 02:40:55', 5700, 6, 'active', 0),
(246, 'jason_rivera', 'jason.r@mail.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jason Rivera', NULL, NULL, 'https://example.com/profiles/jason.jpg', '2023-05-12 07:10:15', NULL, 800, 1, 'active', 0),
(247, 'melissa_cooper', 'melissa.c@domain.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Melissa Cooper', NULL, NULL, NULL, '2023-03-18 03:45:30', '2023-08-21 05:00:45', 7500, 8, 'active', 0),
(248, 'jeffrey_richardson', 'jeffrey.r@email.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jeffrey Richardson', NULL, NULL, 'https://example.com/profiles/jeffrey.png', '2023-06-22 06:20:45', '2023-08-20 08:35:20', 4400, 5, 'active', 0),
(249, 'deborah_howard', 'deborah.h@web.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Deborah Howard', NULL, NULL, 'https://example.com/profiles/deborah.jpg', '2023-01-08 02:55:10', NULL, 1700, 2, 'active', 0),
(250, 'frank_torres', 'frank.t@mail.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Frank Torres', NULL, NULL, NULL, '2023-04-25 09:30:35', '2023-08-19 04:15:50', 9900, 10, 'active', 0),
(251, 'donna_peterson', 'donna.p@domain.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Donna Peterson', NULL, NULL, 'https://example.com/profiles/donna.png', '2023-02-20 05:15:50', '2023-08-22 03:30:15', 6000, 6, 'active', 0),
(253, 'emily_ramirez', 'emily.r@web.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Emily Ramirez', NULL, NULL, NULL, '2023-03-22 07:25:40', '2023-08-21 06:40:55', 8200, 9, 'active', 0),
(254, 'jacob_ward', 'jacob@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jacob Ward', '+63 920 627 4519', 'Vancouver, Canada', 'uploads/profile_images/68c916d39978b_user-profile.png', '2023-06-18 04:10:55', '2025-09-22 07:27:21', 4600, 5, 'active', 0),
(255, 'stephanie_brooks', 'stephanie.b@domain.net', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Stephanie Brooks', NULL, NULL, 'https://example.com/profiles/stephanie.jpg', '2023-01-30 01:45:20', NULL, 2400, 3, 'active', 0),
(256, 'raymond_kelly', 'raymond@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Raymond Kelly', '+63 960 420 8100', '', 'uploads/profile_images/68ca839d11107_Screenshot 2025-08-03 003703.png', '2023-04-12 08:20:45', '2025-09-26 08:59:30', 8800, 9, 'active', 1),
(257, 'lee.allen056628@gmail.com', 'lee.allen056628@gmail.com', '$2y$10$ehs5mI1q5myFjq5npJoKOOC/eaYE3ZkwyUmTOogSbhhqcP7AOH1rW', 'Josh Allen Lee', NULL, NULL, NULL, '2025-08-26 10:54:30', '2025-08-30 11:12:37', 0, 1, 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_exercises`
--

DROP TABLE IF EXISTS `user_exercises`;
CREATE TABLE `user_exercises` (
  `user_exercise_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `exercise_id` int(11) DEFAULT NULL,
  `user_answer` text DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL,
  `xp_earned` int(11) DEFAULT 0,
  `hint_used` tinyint(1) DEFAULT 0,
  `completion_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_progress`
--

DROP TABLE IF EXISTS `user_progress`;
CREATE TABLE `user_progress` (
  `progress_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `completion_status` enum('not_started','in_progress','completed') DEFAULT 'not_started',
  `start_date` timestamp NULL DEFAULT NULL,
  `completion_date` timestamp NULL DEFAULT NULL,
  `time_spent` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  `attempts` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `exercises`
--
ALTER TABLE `exercises`
  ADD PRIMARY KEY (`exercise_id`),
  ADD KEY `module_id` (`module_id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`module_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_exercises`
--
ALTER TABLE `user_exercises`
  ADD PRIMARY KEY (`user_exercise_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `exercise_id` (`exercise_id`);

--
-- Indexes for table `user_progress`
--
ALTER TABLE `user_progress`
  ADD PRIMARY KEY (`progress_id`),
  ADD UNIQUE KEY `unique_user_module` (`user_id`,`module_id`),
  ADD KEY `module_id` (`module_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `exercises`
--
ALTER TABLE `exercises`
  MODIFY `exercise_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=258;

--
-- AUTO_INCREMENT for table `user_exercises`
--
ALTER TABLE `user_exercises`
  MODIFY `user_exercise_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_progress`
--
ALTER TABLE `user_progress`
  MODIFY `progress_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `exercises`
--
ALTER TABLE `exercises`
  ADD CONSTRAINT `exercises_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`);

--
-- Constraints for table `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);

--
-- Constraints for table `user_exercises`
--
ALTER TABLE `user_exercises`
  ADD CONSTRAINT `user_exercises_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `user_exercises_ibfk_2` FOREIGN KEY (`exercise_id`) REFERENCES `exercises` (`exercise_id`);

--
-- Constraints for table `user_progress`
--
ALTER TABLE `user_progress`
  ADD CONSTRAINT `user_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `user_progress_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
